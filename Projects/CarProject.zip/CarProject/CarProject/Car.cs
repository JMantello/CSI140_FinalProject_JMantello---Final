﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarProject
{
    class Car
    {
        private string _make;
        private string _model;
        private int _year;
        private int _mileage;
        private double _price;

        public Car(string make, string model, int year,
                   int mileage, double price)
        {
            _make = make;
            _model = model;
            _year = year;
            _mileage = mileage;
            _price = price;
        }

        public string Make
        {
            get { return _make; }
        }
        public string Model
        {
            get { return _model; }
        }
        public int Year
        {
            get { return _year; }
        }
        public int Mileage
        {
            get { return _mileage; }
        }
        public double Price
        {
            get { return _price; }
        }

        private void ReducePriceBy(double percent)
        {
            _price /= percent;
        }
    }
}
