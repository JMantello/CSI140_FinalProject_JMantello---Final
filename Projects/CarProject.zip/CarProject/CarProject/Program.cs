﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarProject
{
    class Program
    {
        static void Main(string[] args)
        {
            //Create list of Cars
            List<Car> carList = new List<Car>();
            Car lamb0 = new Car("Lamborghini", "Urus", 2021, 0, 203995);
            Car lamb1 = new Car("Lamborghini", "Huracan Evo", 2021, 0, 261274);
            Car lamb2 = new Car("Lamborghini", "Hurican Evo Spyder", 2021, 0, 247400);
            Car lamb3 = new Car("Lamborghini", "Aventador S", 2021, 0, 417650);
            Car lamb4 = new Car("Lamborghini", "Muria", 1966, 112895, 350000);
            Car lamb5 = new Car("Lamborghini", "Espada", 1973, 76159, 67500);
            carList.Add(lamb0);
            carList.Add(lamb1);
            carList.Add(lamb2);
            carList.Add(lamb3);
            carList.Add(lamb4);
            carList.Add(lamb5);

            //Display
            DisplayCars(carList);

            double totalPrice = ComputeTotalPrices(carList);
            Console.WriteLine($"The total price is: {totalPrice.ToString("C2")}\n");
        }

        private static void DisplayCars(List<Car> list)
        {
            foreach(Car car in list)
            {
                Console.WriteLine($"Make: {car.Make}");
                Console.WriteLine($"Model: {car.Model}");
                Console.WriteLine($"Year: {car.Year}");
                Console.WriteLine($"Mileage: {car.Mileage}");
                Console.WriteLine($"Price: {car.Price}");
                Console.WriteLine();
            }
        }

        private static double ComputeTotalPrices(List<Car> list)
        {
            double totalPrice = 0;

            foreach (Car car in list)
                totalPrice += car.Price;

            return totalPrice;
        }
    }
}
