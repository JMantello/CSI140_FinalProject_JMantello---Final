﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LaptopSimulator
{
    public class Laptop
    {
        private bool _power;
        private bool _charging;
        private int _batteryLvl;
        private int _brightnessLvl;
        private int _audioLvl;
        private int _temperature; //F
        private int _fanSpeed;


        public Laptop()
        {
            _power = false;
            _charging = false;
            _batteryLvl = 80;
            _brightnessLvl = 50;
            _audioLvl = 50;
            _temperature = 80;
            _fanSpeed = 2500;
        }

        public bool Power { get { return _power; } }
        public bool Charging { get { return _charging; } }
        public int BatteryLvl { get { return _batteryLvl; } }
        public int BrightnessLvl { get { return _brightnessLvl; } }
        public int AudioLvl { get { return _audioLvl; } }
        public int Temperature { get { return _temperature; } }
        public int FanSpeed { get { return _fanSpeed; } }

        //power
        public void TogglePowerBtn()
        {
            _power = !_power;
        }

        //charging
        public void ToggleChargingStatus()
        {
            _charging = !_charging;
        }

        //brightness
        public void BrightnessMax()
        {
            _brightnessLvl = 100;
        }

        public void BrightnessUp()
        {
            if (_brightnessLvl < 100)
                _brightnessLvl += 10;
        }

        public void BrightnessDown()
        {
            if (_brightnessLvl > 0)
                _brightnessLvl -= 10;
        }

        public void BrightnessMin()
        {
            _brightnessLvl = 0;
        }

        //audio
        public void AudioMax()
        {
            _audioLvl = 100;
        }

        public void AudioUp()
        {
            if (_audioLvl < 100)
                _audioLvl += 10;
        }

        public void AudioDown()
        {
            if (_audioLvl > 0)
                _audioLvl -= 10;
        }

        public void AudioMin()
        {
            _audioLvl = 0;
        }

        //set fan speed
        public void SetFanSpeed(int fanspeed)
        {
            if (fanspeed > 2000 && fanspeed < 7000)
                _fanSpeed = fanspeed;
        }
    }
}
