﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LaptopSimulator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //laptop object
        private Laptop laptop = new Laptop();

        //power
        private void btnPower_Click(object sender, EventArgs e)
        {
            laptop.TogglePowerBtn();
            pnlMain.Visible = !pnlMain.Visible;
            lbBatteryLvl.Text = laptop.BatteryLvl.ToString() + "%";
            lbAudioLevel.Text = laptop.AudioLvl.ToString();
            lbBrightnessLvl.Text = laptop.BrightnessLvl.ToString();
            if (laptop.Charging)
                lbChargingStatus.Text = "Charging";
            else
                lbChargingStatus.Text = "Not Charging";
            lbTemperature.Text = laptop.Temperature.ToString() + " F";
            lbFanSpeed.Text = laptop.FanSpeed.ToString() + " RPM";

        }

        //charging
        private void btnCharge_Click(object sender, EventArgs e)
        {
            laptop.ToggleChargingStatus();
            if (laptop.Charging)
                lbChargingStatus.Text = "Charging";
            else
                lbChargingStatus.Text = "Not Charging";
        }

        //volume
        private void btnVolMax_Click(object sender, EventArgs e)
        {
            laptop.AudioMax();
            lbAudioLevel.Text = laptop.AudioLvl.ToString();
        }

        private void btnVolUp_Click(object sender, EventArgs e)
        {
            laptop.AudioUp();
            lbAudioLevel.Text = laptop.AudioLvl.ToString();
        }

        private void btnVolDown_Click(object sender, EventArgs e)
        {
            laptop.AudioDown();
            lbAudioLevel.Text = laptop.AudioLvl.ToString();
        }

        private void btnVolMin_Click(object sender, EventArgs e)
        {
            laptop.AudioMin();
            lbAudioLevel.Text = laptop.AudioLvl.ToString();
        }

        //brightness
        private void btnBrightMax_Click(object sender, EventArgs e)
        {
            laptop.BrightnessMax();
            lbBrightnessLvl.Text = laptop.BrightnessLvl.ToString();
        }

        private void btnBrightUp_Click(object sender, EventArgs e)
        {
            laptop.BrightnessUp();
            lbBrightnessLvl.Text = laptop.BrightnessLvl.ToString();
        }

        private void btnBrightDown_Click(object sender, EventArgs e)
        {
            laptop.BrightnessDown();
            lbBrightnessLvl.Text = laptop.BrightnessLvl.ToString();
        }

        private void btnBrightMin_Click(object sender, EventArgs e)
        {
            laptop.BrightnessMin();
            lbBrightnessLvl.Text = laptop.BrightnessLvl.ToString();
        }

        private void btnSetFanSpeed_Click(object sender, EventArgs e)
        {
            try
            {
                int fanSpeed = int.Parse(tbFanSpeedInput.Text);
                laptop.SetFanSpeed(fanSpeed);
                lbFanSpeed.Text = laptop.FanSpeed.ToString() + " RPM";
                tbFanSpeedInput.Clear();
            }
            catch
            {
                MessageBox.Show("Fan speed must be between 2000-7000");
            }
        }
    }
}
