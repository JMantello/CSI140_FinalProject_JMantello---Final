﻿
namespace LaptopSimulator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlControl = new System.Windows.Forms.Panel();
            this.btnSetFanSpeed = new System.Windows.Forms.Button();
            this.tbFanSpeedInput = new System.Windows.Forms.TextBox();
            this.btnBrightMin = new System.Windows.Forms.Button();
            this.btnBrightMax = new System.Windows.Forms.Button();
            this.btnBrightDown = new System.Windows.Forms.Button();
            this.btnBrightUp = new System.Windows.Forms.Button();
            this.btnVolMin = new System.Windows.Forms.Button();
            this.btnVolMax = new System.Windows.Forms.Button();
            this.btnVolDown = new System.Windows.Forms.Button();
            this.btnVolUp = new System.Windows.Forms.Button();
            this.btnCharge = new System.Windows.Forms.Button();
            this.btnPower = new System.Windows.Forms.Button();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.lbChargingStatus = new System.Windows.Forms.Label();
            this.lbBatteryLvl = new System.Windows.Forms.Label();
            this.lbFanSpeed = new System.Windows.Forms.Label();
            this.lbTemperature = new System.Windows.Forms.Label();
            this.lbAudioLevel = new System.Windows.Forms.Label();
            this.lbBrightnessLvl = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pnlControl.SuspendLayout();
            this.pnlMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlControl
            // 
            this.pnlControl.Controls.Add(this.btnSetFanSpeed);
            this.pnlControl.Controls.Add(this.tbFanSpeedInput);
            this.pnlControl.Controls.Add(this.btnBrightMin);
            this.pnlControl.Controls.Add(this.btnBrightMax);
            this.pnlControl.Controls.Add(this.btnBrightDown);
            this.pnlControl.Controls.Add(this.btnBrightUp);
            this.pnlControl.Controls.Add(this.btnVolMin);
            this.pnlControl.Controls.Add(this.btnVolMax);
            this.pnlControl.Controls.Add(this.btnVolDown);
            this.pnlControl.Controls.Add(this.btnVolUp);
            this.pnlControl.Controls.Add(this.btnCharge);
            this.pnlControl.Controls.Add(this.btnPower);
            this.pnlControl.Location = new System.Drawing.Point(151, 731);
            this.pnlControl.Name = "pnlControl";
            this.pnlControl.Size = new System.Drawing.Size(1162, 169);
            this.pnlControl.TabIndex = 0;
            // 
            // btnSetFanSpeed
            // 
            this.btnSetFanSpeed.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSetFanSpeed.Location = new System.Drawing.Point(219, 120);
            this.btnSetFanSpeed.Name = "btnSetFanSpeed";
            this.btnSetFanSpeed.Size = new System.Drawing.Size(170, 49);
            this.btnSetFanSpeed.TabIndex = 2;
            this.btnSetFanSpeed.Text = "Set Fan Speed";
            this.btnSetFanSpeed.UseVisualStyleBackColor = true;
            this.btnSetFanSpeed.Click += new System.EventHandler(this.btnSetFanSpeed_Click);
            // 
            // tbFanSpeedInput
            // 
            this.tbFanSpeedInput.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbFanSpeedInput.Location = new System.Drawing.Point(3, 120);
            this.tbFanSpeedInput.Name = "tbFanSpeedInput";
            this.tbFanSpeedInput.Size = new System.Drawing.Size(210, 32);
            this.tbFanSpeedInput.TabIndex = 1;
            // 
            // btnBrightMin
            // 
            this.btnBrightMin.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBrightMin.Location = new System.Drawing.Point(96, 3);
            this.btnBrightMin.Name = "btnBrightMin";
            this.btnBrightMin.Size = new System.Drawing.Size(124, 81);
            this.btnBrightMin.TabIndex = 0;
            this.btnBrightMin.Text = "Brightness Min";
            this.btnBrightMin.UseVisualStyleBackColor = true;
            this.btnBrightMin.Click += new System.EventHandler(this.btnBrightMin_Click);
            // 
            // btnBrightMax
            // 
            this.btnBrightMax.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBrightMax.Location = new System.Drawing.Point(486, 3);
            this.btnBrightMax.Name = "btnBrightMax";
            this.btnBrightMax.Size = new System.Drawing.Size(124, 81);
            this.btnBrightMax.TabIndex = 0;
            this.btnBrightMax.Text = "Brightness Max";
            this.btnBrightMax.UseVisualStyleBackColor = true;
            this.btnBrightMax.Click += new System.EventHandler(this.btnBrightMax_Click);
            // 
            // btnBrightDown
            // 
            this.btnBrightDown.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBrightDown.Location = new System.Drawing.Point(226, 3);
            this.btnBrightDown.Name = "btnBrightDown";
            this.btnBrightDown.Size = new System.Drawing.Size(124, 81);
            this.btnBrightDown.TabIndex = 0;
            this.btnBrightDown.Text = "Brightness-";
            this.btnBrightDown.UseVisualStyleBackColor = true;
            this.btnBrightDown.Click += new System.EventHandler(this.btnBrightDown_Click);
            // 
            // btnBrightUp
            // 
            this.btnBrightUp.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBrightUp.Location = new System.Drawing.Point(356, 3);
            this.btnBrightUp.Name = "btnBrightUp";
            this.btnBrightUp.Size = new System.Drawing.Size(124, 81);
            this.btnBrightUp.TabIndex = 0;
            this.btnBrightUp.Text = "Brightness+";
            this.btnBrightUp.UseVisualStyleBackColor = true;
            this.btnBrightUp.Click += new System.EventHandler(this.btnBrightUp_Click);
            // 
            // btnVolMin
            // 
            this.btnVolMin.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVolMin.Location = new System.Drawing.Point(616, 3);
            this.btnVolMin.Name = "btnVolMin";
            this.btnVolMin.Size = new System.Drawing.Size(96, 81);
            this.btnVolMin.TabIndex = 0;
            this.btnVolMin.Text = "Vol Min";
            this.btnVolMin.UseVisualStyleBackColor = true;
            this.btnVolMin.Click += new System.EventHandler(this.btnVolMin_Click);
            // 
            // btnVolMax
            // 
            this.btnVolMax.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVolMax.Location = new System.Drawing.Point(922, 3);
            this.btnVolMax.Name = "btnVolMax";
            this.btnVolMax.Size = new System.Drawing.Size(105, 81);
            this.btnVolMax.TabIndex = 0;
            this.btnVolMax.Text = "Vol Max";
            this.btnVolMax.UseVisualStyleBackColor = true;
            this.btnVolMax.Click += new System.EventHandler(this.btnVolMax_Click);
            // 
            // btnVolDown
            // 
            this.btnVolDown.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVolDown.Location = new System.Drawing.Point(718, 3);
            this.btnVolDown.Name = "btnVolDown";
            this.btnVolDown.Size = new System.Drawing.Size(96, 81);
            this.btnVolDown.TabIndex = 0;
            this.btnVolDown.Text = "Vol-";
            this.btnVolDown.UseVisualStyleBackColor = true;
            this.btnVolDown.Click += new System.EventHandler(this.btnVolDown_Click);
            // 
            // btnVolUp
            // 
            this.btnVolUp.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVolUp.Location = new System.Drawing.Point(820, 3);
            this.btnVolUp.Name = "btnVolUp";
            this.btnVolUp.Size = new System.Drawing.Size(96, 81);
            this.btnVolUp.TabIndex = 0;
            this.btnVolUp.Text = "Vol+";
            this.btnVolUp.UseVisualStyleBackColor = true;
            this.btnVolUp.Click += new System.EventHandler(this.btnVolUp_Click);
            // 
            // btnCharge
            // 
            this.btnCharge.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCharge.Location = new System.Drawing.Point(922, 85);
            this.btnCharge.Name = "btnCharge";
            this.btnCharge.Size = new System.Drawing.Size(207, 81);
            this.btnCharge.TabIndex = 0;
            this.btnCharge.Text = "Charger on/off";
            this.btnCharge.UseVisualStyleBackColor = true;
            this.btnCharge.Click += new System.EventHandler(this.btnCharge_Click);
            // 
            // btnPower
            // 
            this.btnPower.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPower.Location = new System.Drawing.Point(1033, 3);
            this.btnPower.Name = "btnPower";
            this.btnPower.Size = new System.Drawing.Size(96, 81);
            this.btnPower.TabIndex = 0;
            this.btnPower.Text = "Power";
            this.btnPower.UseVisualStyleBackColor = true;
            this.btnPower.Click += new System.EventHandler(this.btnPower_Click);
            // 
            // pnlMain
            // 
            this.pnlMain.Controls.Add(this.lbChargingStatus);
            this.pnlMain.Controls.Add(this.lbBatteryLvl);
            this.pnlMain.Controls.Add(this.lbFanSpeed);
            this.pnlMain.Controls.Add(this.lbTemperature);
            this.pnlMain.Controls.Add(this.lbAudioLevel);
            this.pnlMain.Controls.Add(this.lbBrightnessLvl);
            this.pnlMain.Controls.Add(this.label7);
            this.pnlMain.Controls.Add(this.label5);
            this.pnlMain.Controls.Add(this.label3);
            this.pnlMain.Controls.Add(this.label1);
            this.pnlMain.Location = new System.Drawing.Point(151, 175);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(1162, 550);
            this.pnlMain.TabIndex = 1;
            this.pnlMain.Visible = false;
            // 
            // lbChargingStatus
            // 
            this.lbChargingStatus.AutoSize = true;
            this.lbChargingStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbChargingStatus.Location = new System.Drawing.Point(992, 70);
            this.lbChargingStatus.Name = "lbChargingStatus";
            this.lbChargingStatus.Size = new System.Drawing.Size(111, 29);
            this.lbChargingStatus.TabIndex = 0;
            this.lbChargingStatus.Text = "Charging";
            // 
            // lbBatteryLvl
            // 
            this.lbBatteryLvl.AutoSize = true;
            this.lbBatteryLvl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbBatteryLvl.Location = new System.Drawing.Point(992, 25);
            this.lbBatteryLvl.Name = "lbBatteryLvl";
            this.lbBatteryLvl.Size = new System.Drawing.Size(115, 29);
            this.lbBatteryLvl.TabIndex = 0;
            this.lbBatteryLvl.Text = "batteryLvl";
            // 
            // lbFanSpeed
            // 
            this.lbFanSpeed.AutoSize = true;
            this.lbFanSpeed.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbFanSpeed.Location = new System.Drawing.Point(313, 375);
            this.lbFanSpeed.Name = "lbFanSpeed";
            this.lbFanSpeed.Size = new System.Drawing.Size(126, 46);
            this.lbFanSpeed.TabIndex = 0;
            this.lbFanSpeed.Text = "label1";
            // 
            // lbTemperature
            // 
            this.lbTemperature.AutoSize = true;
            this.lbTemperature.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTemperature.Location = new System.Drawing.Point(313, 289);
            this.lbTemperature.Name = "lbTemperature";
            this.lbTemperature.Size = new System.Drawing.Size(126, 46);
            this.lbTemperature.TabIndex = 0;
            this.lbTemperature.Text = "label1";
            // 
            // lbAudioLevel
            // 
            this.lbAudioLevel.AutoSize = true;
            this.lbAudioLevel.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbAudioLevel.Location = new System.Drawing.Point(313, 200);
            this.lbAudioLevel.Name = "lbAudioLevel";
            this.lbAudioLevel.Size = new System.Drawing.Size(126, 46);
            this.lbAudioLevel.TabIndex = 0;
            this.lbAudioLevel.Text = "label1";
            // 
            // lbBrightnessLvl
            // 
            this.lbBrightnessLvl.AutoSize = true;
            this.lbBrightnessLvl.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbBrightnessLvl.Location = new System.Drawing.Point(313, 113);
            this.lbBrightnessLvl.Name = "lbBrightnessLvl";
            this.lbBrightnessLvl.Size = new System.Drawing.Size(126, 46);
            this.lbBrightnessLvl.TabIndex = 0;
            this.lbBrightnessLvl.Text = "label1";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(82, 375);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(225, 46);
            this.label7.TabIndex = 0;
            this.label7.Text = "Fan Speed:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(50, 289);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(257, 46);
            this.label5.TabIndex = 0;
            this.label5.Text = "Temperature:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(68, 200);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(239, 46);
            this.label3.TabIndex = 0;
            this.label3.Text = "Audio Level:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(88, 113);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(219, 46);
            this.label1.TabIndex = 0;
            this.label1.Text = "Brightness:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1462, 1140);
            this.Controls.Add(this.pnlMain);
            this.Controls.Add(this.pnlControl);
            this.Name = "Form1";
            this.Text = "Laptop Main";
            this.pnlControl.ResumeLayout(false);
            this.pnlControl.PerformLayout();
            this.pnlMain.ResumeLayout(false);
            this.pnlMain.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlControl;
        private System.Windows.Forms.Button btnBrightMax;
        private System.Windows.Forms.Button btnBrightDown;
        private System.Windows.Forms.Button btnBrightUp;
        private System.Windows.Forms.Button btnVolMin;
        private System.Windows.Forms.Button btnVolMax;
        private System.Windows.Forms.Button btnVolDown;
        private System.Windows.Forms.Button btnVolUp;
        private System.Windows.Forms.Button btnPower;
        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.Button btnSetFanSpeed;
        private System.Windows.Forms.TextBox tbFanSpeedInput;
        private System.Windows.Forms.Button btnBrightMin;
        private System.Windows.Forms.Button btnCharge;
        private System.Windows.Forms.Label lbBatteryLvl;
        private System.Windows.Forms.Label lbFanSpeed;
        private System.Windows.Forms.Label lbTemperature;
        private System.Windows.Forms.Label lbAudioLevel;
        private System.Windows.Forms.Label lbBrightnessLvl;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbChargingStatus;
    }
}

